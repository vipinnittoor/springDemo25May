package com.infy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
 
import com.infy.entity.Room;

public interface RoomRepository extends JpaRepository<Room , String>{

}
