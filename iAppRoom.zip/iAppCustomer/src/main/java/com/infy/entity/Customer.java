package com.infy.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // gett setter 
@NoArgsConstructor // add 
@AllArgsConstructor // add
@Entity  // the customer is a ORM the tabel 
public class Customer {
@Id // primary key 
private String cid;
private String cname;
private String caddress;
private Date dob;   
private String room_rid;

}
