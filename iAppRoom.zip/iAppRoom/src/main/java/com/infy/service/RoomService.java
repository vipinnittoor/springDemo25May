package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.Room;
import com.infy.repository.RoomRepository;
@Service
public class RoomService {
	@Autowired
	RoomRepository roomRepository;

	public List<Room> getallData() {
		 List<Room> roomList =roomRepository.findAll();
	  
		 return roomList;

	}

	public Room addData(Room  r)   {

		 
		return roomRepository.save(r);

		// TODO Auto-generated method stub

	}

	public  Room  getRoomDetails(String rid) {
		// TODO Auto-generated method stub
		return roomRepository.findById(rid).get();
	}
}
