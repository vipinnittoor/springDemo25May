package com.infy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableFeignClients
public class IAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(IAppApplication.class, args);
	}

	@Bean
	RestTemplate restTemplate() {

		return new RestTemplate();
	}
}
