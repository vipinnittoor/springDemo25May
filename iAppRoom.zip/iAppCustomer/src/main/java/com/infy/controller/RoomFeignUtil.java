package com.infy.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.infy.entity.Room;

@FeignClient(value = "RoomService", url = "http://localhost:8097/iapp/" ) // enables as a proxy to the resttmeplate 
public interface RoomFeignUtil {
	
	@GetMapping("/room")
	public List<Room> getallRoom()  ;
	@GetMapping("/{rid}")
	public  Room  getRoom(@PathVariable String rid) ;
	@PostMapping("/room")
	public  Room  addData(@RequestBody Room room) throws ParseException;
}
