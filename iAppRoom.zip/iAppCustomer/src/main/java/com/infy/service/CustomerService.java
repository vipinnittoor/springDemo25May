package com.infy.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.CustomerDTO;
import com.infy.entity.Customer;
import com.infy.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;

	public List<Customer > getallData() {
		 List<Customer> customerList =customerRepository.findAll();
		
	//	 List<CustomerDTO> customerDTOlist= new ArrayList<>();
		 
		 
		 return customerList;

	}

	public Customer addData(Customer  c) throws ParseException {

		 
//		c.setCaddress(customerDTO.getCaddress());
//		c.setCid(customerDTO.getCid());
//		c.setCname(customerDTO.getCname());
// 		Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse("23-09-2022");
// 	c.setDob((java.sql.Date) date1);
 
		return customerRepository.save(c);

		// TODO Auto-generated method stub

	}

	public Customer getData(String cid) {
		// TODO Auto-generated method stub
		return customerRepository.findById(cid).get();
	}

}
