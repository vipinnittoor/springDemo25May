
package com.infy.dto;

import com.infy.entity.Room;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // gett setter 
@NoArgsConstructor // add 
@AllArgsConstructor // add
 
public class CustomerDTO {
 
private String cid;
private String cname;
private String caddress;
private int age;
private Room room ;

}
