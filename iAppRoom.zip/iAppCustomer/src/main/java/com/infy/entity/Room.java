package com.infy.entity;


import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // gett setter 
@NoArgsConstructor // add 
@AllArgsConstructor // add  
public class Room { 
	private String rid; 
	private int cost;
	private String typeofRoom;
	private boolean airc;

}
