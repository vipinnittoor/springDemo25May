package com.infy.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.dto.CustomerDTO;
import com.infy.entity.Customer;
import com.infy.entity.Room;
import com.infy.service.CustomerService;

@RestController
@RequestMapping("/iapp")
public class CustomerController {

	@Autowired
	CustomerService customerService;

 	@Autowired
 	RoomFeignUtil roomFeignUtil;
//	RestTemplate restTemplate;
//
//	 
	
	

	@GetMapping("/{cid}")
	public CustomerDTO getCustomer(@PathVariable String cid) {
		Customer c = customerService.getData(cid);
		String rid = c.getRoom_rid();

		String url = "http://localhost:8097/iapp/" + rid;

	//	Room r = restTemplate.getForObject(url, Room.class);
		
		Room r =roomFeignUtil.getRoom(rid);
		CustomerDTO cdto= new CustomerDTO();
		cdto.setRoom(r); 
		cdto.setCaddress(c.getCaddress());
		cdto.setCid(c.getCid());
		cdto.setCname(c.getCname());
		return cdto;

	}

	@PostMapping("/customer")
	public Customer addData(@RequestBody Customer customer) throws ParseException {

		return customerService.addData(customer);

	}

}
